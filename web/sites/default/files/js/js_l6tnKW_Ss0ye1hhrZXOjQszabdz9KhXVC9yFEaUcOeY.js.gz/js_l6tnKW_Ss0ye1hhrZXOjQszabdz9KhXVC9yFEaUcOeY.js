/*! @drupal/once - v1.0.1 - 2021-06-12 */
var once=function(){"use strict";var n=/[\11\12\14\15\40]+/,e="data-once",t=document;function r(n,t,r){return n[t+"Attribute"](e,r)}function o(e){if("string"!=typeof e)throw new TypeError("once ID must be a string");if(""===e||n.test(e))throw new RangeError("once ID must not be empty or contain spaces");return'[data-once~="'+e+'"]'}function u(n){if(!(n instanceof Element))throw new TypeError("The element must be an instance of Element");return!0}function i(n,e){void 0===e&&(e=t);var r=n;if(null===n)r=[];else{if(!n)throw new TypeError("Selector must not be empty");"string"!=typeof n||e!==t&&!u(e)?n instanceof Element&&(r=[n]):r=e.querySelectorAll(n)}return Array.prototype.slice.call(r)}function c(n,e,t){return e.filter((function(e){var r=u(e)&&e.matches(n);return r&&t&&t(e),r}))}function f(e,t){var o=t.add,u=t.remove,i=[];r(e,"has")&&r(e,"get").trim().split(n).forEach((function(n){i.indexOf(n)<0&&n!==u&&i.push(n)})),o&&i.push(o);var c=i.join(" ");r(e,""===c?"remove":"set",c)}function a(n,e,t){return c(":not("+o(n)+")",i(e,t),(function(e){return f(e,{add:n})}))}return a.remove=function(n,e,t){return c(o(n),i(e,t),(function(e){return f(e,{remove:n})}))},a.filter=function(n,e,t){return c(o(n),i(e,t))},a.find=function(n,e){return i(n?o(n):"[data-once]",e)},a}();

;
window.drupalTranslations = {"strings":{"":{"Home":"Inicio","Next":"Siguiente","closed":"Cerrado","Cancel":"Cancelar","Disabled":"Desactivado","Enabled":"Activado","Edit":"Editar","Link":"Enlace","Image":"Image","Open":"Abierta","Sunday":"Domingo","Monday":"Lunes","Tuesday":"Martes","Wednesday":"Mi\u00e9rcoles","Thursday":"Jueves","Friday":"Viernes","Saturday":"S\u00e1bado","Add":"Agregar","Continue":"Continuar","Mon":"Lun","Tue":"Mar","Wed":"Mi\u00e9","Thu":"Jue","Fri":"Vie","Sat":"S\u00e1b","Sun":"Dom","May":"Mayo","Close":"Close","Add group":"A\u00f1adir grupo","Show":"Mostrar","Select all rows in this table":"Seleccionar todas las filas de esta tabla","Deselect all rows in this table":"Quitar la selecci\u00f3n a todas las filas de esta tabla","Jan":"Ene","Feb":"Feb","Mar":"Mar","Apr":"Abr","Jun":"Jun","Jul":"Jul","Aug":"Ago","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dic","Caption":"Etiqueta","Extend":"Ampliar","Changed":"Modificado","Not published":"No publicado","Loading...":"Cargando...","Apply":"Apply","Please wait...":"Espere, por favor...","Hide":"Ocultar","Unlink":"Desvincular","Not promoted":"No publicado en p\u00e1gina principal","Error message":"Mensaje de error","button":"bot\u00f3n","Warning message":"Mensaje de advertencia","Edit Link":"Editar enlace","Remove group":"Eliminar grupo","By @name on @date":"Por @name en @date","By @name":"Por @name","Not in menu":"No est\u00e1 en un men\u00fa","Alias: @alias":"Alias: @alias","No alias":"Sin alias","@label":"@label","New revision":"Nueva revisi\u00f3n","Drag to re-order":"Arrastre para reordenar","Changes made in this table will not be saved until the form is submitted.":"Los cambios realizados en esta tabla no se guardar\u00e1n hasta que se env\u00ede el formulario","Show description":"Mostrar descripci\u00f3n","New group":"Nuevo grupo","Lock":"Bloquear","This permission is inherited from the authenticated user role.":"Este permiso se hereda del rol de usuario registrado.","No revision":"Sin revisi\u00f3n","Requires a title":"Necesita un t\u00edtulo","Not restricted":"Sin restricci\u00f3n","(active tab)":"(solapa activa)","Status message":"Mensaje de estado","An AJAX HTTP error occurred.":"Hubo un error HTTP AJAX.","HTTP Result Code: !status":"C\u00f3digo de Resultado HTTP: !status","An AJAX HTTP request terminated abnormally.":"Una solicitud HTTP de AJAX termin\u00f3 de manera anormal.","Debugging information follows.":"A continuaci\u00f3n se detalla la informaci\u00f3n de depuraci\u00f3n.","Path: !uri":"Ruta: !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseText: !responseText","ReadyState: !readyState":"ReadyState: !readyState","Restricted to certain pages":"Restringido a algunas p\u00e1ginas","The block cannot be placed in this region.":"El bloque no se puede colocar en esta regi\u00f3n.","Hide summary":"Ocultar resumen","Edit summary":"Editar resumen","Don\u0027t display post information":"No mostrar informaci\u00f3n del env\u00edo","Unlock":"Desbloquear","Collapse":"Plegar","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"El archivo seleccionado %filename no se puede subir al servidor. Solo se permiten archivos con las siguientes extensiones: %extensions.","Show row weights":"Mostrar pesos de la fila","Hide row weights":"Ocultar pesos de la fila","Apply (all displays)":"Aplicar (todas las presentaciones)","Apply (this display)":"Aplicar (esta presentaci\u00f3n)","Revert to default":"Volver a los valores predeterminados","Hide description":"Esconder descripci\u00f3n","Does not need to be updated":"No necesita ser actualizado","Show all columns":"Mostrar todas las columnas","Show table cells that were hidden to make the table fit within a small screen.":"Mostrar celdas de tablas que estaban ocultas para que la tabla se ajuste a una pantalla peque\u00f1a.","List additional actions":"Lista adicional de acciones","Flag other translations as outdated":"Marcar las otras traducciones como obsoletas","Do not flag other translations as outdated":"No marcar las otras traducciones como obsoletas","opened":"abierto","Horizontal orientation":"Orientaci\u00f3n horizontal","Vertical orientation":"Orientaci\u00f3n vertical","Tray orientation changed to @orientation.":"La orientaci\u00f3n de la bandeja se ha cambiado a @orientation.","You have unsaved changes.":"Hay cambios sin guardar.","No styles configured":"Ning\u00fan estilo configurado","@count styles configured":"@count estilos configurados","@action @title configuration options":"@action @title opciones de configuraci\u00f3n","Tabbing is no longer constrained by the Contextual module.":"Tabulando (Tabbing) ya no se ver\u00e1 limitado por el m\u00f3dulo Contextual (Contextual).","Tabbing is constrained to a set of @contextualsCount and the edit mode toggle.":"La tabulaci\u00f3n est\u00e1 restringida a un conjunto de @contextualsCount y al cambio a modo de edici\u00f3n.","Press the esc key to exit.":"Presionar tecla esc para salir.","@count contextual link\u0003@count contextual links":"@count enlace contextual\u0003@count enlaces contextuales","Based on the text editor configuration, these tags have automatically been added: \u003Cstrong\u003E@tag-list\u003C\/strong\u003E.":"Basado en la configuraci\u00f3n del editor de texto, esas etiquetas fueron a\u00f1adidas autom\u00e1ticamente:  \u003Cstrong\u003E@tag-list\u003C\/strong\u003E.","!tour_item of !total":"!tour_item de !total","End tour":"Final del recorrido","Uploads disabled":"Subidas desactivadas","Uploads enabled, max size: @size @dimensions":"Subidas activadas, tama\u00f1o m\u00e1ximo: @size @dimensions","The toolbar cannot be set to a horizontal orientation when it is locked.":"La barra de herramientas no puede ser puesta en orientaci\u00f3n horizontal cuando esta bloqueada.","Enter caption here":"Especifique el t\u00edtulo aqu\u00ed","Hide group names":"Ocultar grupos de nombres","Show group names":"Mostrar grupos de nombres","@groupName button group in position @position of @positionCount in row @row of @rowCount.":"Grupo de botones \u0022@groupName\u0022 en posici\u00f3n @position de @positionCount en la fila @row de @rowCount.","Press the down arrow key to create a new row.":"Oprima la tecla fecha abajo para crear una nueva fila.","@name @type.":"@type @name.","Press the down arrow key to activate.":"Oprima la tecla fecha abajo para activar.","@name @type in position @position of @positionCount in @groupName button group in row @row of @rowCount.":"@name @type en posici\u00f3n @position de @positionCount en el grupo de botones @groupName en la fila @row de @rowCount.","Press the down arrow key to create a new button group in a new row.":"Oprima la tecla fecha abajo para crear un nuevo grupo de botones en una nueva fila.","This is the last group. Move the button forward to create a new group.":"Este es el \u00faltimo grupo. Mueve el bot\u00f3n adelante para crear un nuevo grupo.","The \u0022@name\u0022 button is currently enabled.":"El bot\u00f3n @name est\u00e1 actualmente habilitado.","Use the keyboard arrow keys to change the position of this button.":"Use las teclas de fecha del teclado para cambiar la posici\u00f3n de este bot\u00f3n.","Press the up arrow key on the top row to disable the button.":"Oprima la tecla fecha arriba arriba de la fila para desabilitar el bot\u00f3n.","The \u0022@name\u0022 button is currently disabled.":"El bot\u00f3n de \u0022@name\u0022 est\u00e1 actualmente desactivado.","This @name is currently enabled.":"Este @name est\u00e1 actualmente habilitado.","Use the keyboard arrow keys to change the position of this separator.":"Utilice las teclas de flechas del teclado para cambiar la posici\u00f3n de este separador.","Separators are used to visually split individual buttons.":"Los separadores se utilizan para dividir visualmente botones individuales.","This @name is currently disabled.":"Este @name est\u00e1 actualmente deshabilitado.","Use the down arrow key to move this separator into the active toolbar.":"Utilice las teclas de flecha del teclado para mover este separador en la barra de herramientas activa.","You may add multiple separators to each button group.":"Puede agregar varios separadores para cada grupo de botones.","Please provide a name for the button group.":"Por favor, ingrese un nombre para el grupo de botones.","Button group name":"Nombre del grupo de botones","Editing the name of the new button group in a dialog.":"Editando el nombre del nuevo grupo de botones en un di\u00e1logo.","Editing the name of the \u0022@groupName\u0022 button group in a dialog.":"Editando el nombre del grupo de botones \u0022@groupName\u0022 en un cuadro de di\u00e1logo.","Place a button to create a new button group.":"Coloque un bot\u00f3n para crear un nuevo grupo de botones.","Add a CKEditor button group to the end of this row.":"A\u00f1adir un grupo de botones de CKEditor la final de esta fila.","Changing the text format to %text_format will permanently remove content that is not allowed in that text format.\u003Cbr\u003E\u003Cbr\u003ESave your changes before switching the text format to avoid losing data.":"Cambiar el formato de texto a %text_format eliminar\u00e1 permanentemente el contenido que no est\u00e1 permitido en ese formato de texto.\u003Cbr\u003E\u003Cbr\u003EGuarde sus datos antes de cambiar el formato de texto para evitar perder datos.","Change text format?":"\u00bfCambiar el formato de texto?","Rich Text Editor, !label field":"Editor de texto con formato, campo !label","Leave preview?":"\u00bfSalir de la vista previa?","Leave preview":"Salir de la vista previa","Leaving the preview will cause unsaved changes to be lost. Are you sure you want to leave the preview?":"La salida de la vista previa provocar\u00e1 la p\u00e9rdida de los cambios no guardados. \u00bfEst\u00e1 seguro de que desea abandonar la vista previa?","CTRL+Left click will prevent this dialog from showing and proceed to the clicked link.":"CTRL+Clic izquierdo evitar\u00e1 que aparezca este di\u00e1logo e ir\u00e1 directamente al enlace pulsado.","Tray \u0022@tray\u0022 @action.":"Bandeja \u0022@tray\u0022 @action","Tray @action.":"Bandeja @action.","Hide lower priority columns":"Ocultar columnas de menor prioridad","!modules modules are available in the modified list.":"!modules m\u00f3dulos est\u00e1n disponibles en la lista modificada.","The response failed verification so will not be processed.":"La respuesta de verificaci\u00f3n fall\u00f3, por lo que no se procesar\u00e1.","The callback URL is not local and not trusted: !url":"La URL de callback (llamada) no es local y no es confiable: !url","CustomMessage: !customMessage":"CustomMessage: !customMessage","Authored on @date":"Escrito el @date","1 block is available in the modified list.\u0003@count blocks are available in the modified list.":"1 bloque esta disponible en la lista modificada.\u0003@count bloques est\u00e1n disponibles en la lista modificada.","Zero items selected":"Cero elementos seleccionados","All @count items selected":"Todos los @count elementos seleccionados","Select all media":"Seleccionar todos los elementos multimedia","Show media item weights":"Muestra los pesos de los elementos de contenido multimedia","Hide media item weights":"Oculta los pesos de los elementos de contenido multimedia","All available blocks are listed.":"Se listan todos los bloques disponibles.","Block previews are visible. Block labels are hidden.":"Las vistas previas de bloque son visibles. Las etiquetas de bloque est\u00e1n ocultas.","Block previews are hidden. Block labels are visible.":"Las vistas previas de bloque est\u00e1n ocultas. Las etiquetas de bloque son visibles.","Insert this token into your form":"Inserte este comod\u00edn en su formulario","First click a text field to insert your tokens into.":"Primero haga clic en un campo de texto en el que quiera insertar sus patrones de reemplazo.","Restricted":"Restringido","Automatic alias":"Alias autom\u00e1tico","Done":"Hecho","Prev":"Ant","Today":"Hoy","Su":"Do","Mo":"Lu","Tu":"Ma","We":"Mi","Th":"Ju","Fr":"Vi","Sa":"Sa","mm\/dd\/yy":"dd-mm-yy","One domain with multiple subdomains":"Un dominio con m\u00faltiples subdominios","All pages with exceptions":"Todas las p\u00e1ginas con excepciones","Excepted: @roles":"Exceptuando: @roles","Not customizable":"No personalizable","On by default with opt out":"Activado por defecto con opci\u00f3n de desactivar","Off by default with opt in":"Desactivado por defecto con elecci\u00f3n de activar","Outbound links":"Enlaces salientes","Mailto links":"Enlaces de Correo electr\u00f3nico","Downloads":"Descargas","Colorbox":"Colorbox","Not tracked":"No monitorizado","@items enabled":"@items activado","Site search":"B\u00fasqueda en el sitio","A single domain":"Un \u00fanico dominio","No privacy":"Sin privacidad"},"Long month name":{"January":"Enero","February":"Febrero","March":"Marzo","April":"Abril","May":"Mayo","June":"Junio","July":"Julio","August":"Agosto","September":"Septiembre","October":"Octubre","November":"Noviembre","December":"Diciembre"}},"pluralFormula":{"1":0,"default":1}};;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
(function () {
  var settingsElement = document.querySelector('head > script[type="application/json"][data-drupal-selector="drupal-settings-json"], body > script[type="application/json"][data-drupal-selector="drupal-settings-json"]');
  window.drupalSettings = {};
  if (settingsElement !== null) {
    window.drupalSettings = JSON.parse(settingsElement.textContent);
  }
})();;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
window.Drupal = {
  behaviors: {},
  locale: {}
};
(function (Drupal, drupalSettings, drupalTranslations, console, Proxy, Reflect) {
  Drupal.throwError = function (error) {
    setTimeout(function () {
      throw error;
    }, 0);
  };
  Drupal.attachBehaviors = function (context, settings) {
    context = context || document;
    settings = settings || drupalSettings;
    var behaviors = Drupal.behaviors;
    Object.keys(behaviors || {}).forEach(function (i) {
      if (typeof behaviors[i].attach === 'function') {
        try {
          behaviors[i].attach(context, settings);
        } catch (e) {
          Drupal.throwError(e);
        }
      }
    });
  };
  Drupal.detachBehaviors = function (context, settings, trigger) {
    context = context || document;
    settings = settings || drupalSettings;
    trigger = trigger || 'unload';
    var behaviors = Drupal.behaviors;
    Object.keys(behaviors || {}).forEach(function (i) {
      if (typeof behaviors[i].detach === 'function') {
        try {
          behaviors[i].detach(context, settings, trigger);
        } catch (e) {
          Drupal.throwError(e);
        }
      }
    });
  };
  Drupal.checkPlain = function (str) {
    str = str.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    return str;
  };
  Drupal.formatString = function (str, args) {
    var processedArgs = {};
    Object.keys(args || {}).forEach(function (key) {
      switch (key.charAt(0)) {
        case '@':
          processedArgs[key] = Drupal.checkPlain(args[key]);
          break;
        case '!':
          processedArgs[key] = args[key];
          break;
        default:
          processedArgs[key] = Drupal.theme('placeholder', args[key]);
          break;
      }
    });
    return Drupal.stringReplace(str, processedArgs, null);
  };
  Drupal.stringReplace = function (str, args, keys) {
    if (str.length === 0) {
      return str;
    }
    if (!Array.isArray(keys)) {
      keys = Object.keys(args || {});
      keys.sort(function (a, b) {
        return a.length - b.length;
      });
    }
    if (keys.length === 0) {
      return str;
    }
    var key = keys.pop();
    var fragments = str.split(key);
    if (keys.length) {
      for (var i = 0; i < fragments.length; i++) {
        fragments[i] = Drupal.stringReplace(fragments[i], args, keys.slice(0));
      }
    }
    return fragments.join(args[key]);
  };
  Drupal.t = function (str, args, options) {
    options = options || {};
    options.context = options.context || '';
    if (typeof drupalTranslations !== 'undefined' && drupalTranslations.strings && drupalTranslations.strings[options.context] && drupalTranslations.strings[options.context][str]) {
      str = drupalTranslations.strings[options.context][str];
    }
    if (args) {
      str = Drupal.formatString(str, args);
    }
    return str;
  };
  Drupal.url = function (path) {
    return drupalSettings.path.baseUrl + drupalSettings.path.pathPrefix + path;
  };
  Drupal.url.toAbsolute = function (url) {
    var urlParsingNode = document.createElement('a');
    try {
      url = decodeURIComponent(url);
    } catch (e) {}
    urlParsingNode.setAttribute('href', url);
    return urlParsingNode.cloneNode(false).href;
  };
  Drupal.url.isLocal = function (url) {
    var absoluteUrl = Drupal.url.toAbsolute(url);
    var protocol = window.location.protocol;
    if (protocol === 'http:' && absoluteUrl.indexOf('https:') === 0) {
      protocol = 'https:';
    }
    var baseUrl = "".concat(protocol, "//").concat(window.location.host).concat(drupalSettings.path.baseUrl.slice(0, -1));
    try {
      absoluteUrl = decodeURIComponent(absoluteUrl);
    } catch (e) {}
    try {
      baseUrl = decodeURIComponent(baseUrl);
    } catch (e) {}
    return absoluteUrl === baseUrl || absoluteUrl.indexOf("".concat(baseUrl, "/")) === 0;
  };
  Drupal.formatPlural = function (count, singular, plural, args, options) {
    args = args || {};
    args['@count'] = count;
    var pluralDelimiter = drupalSettings.pluralDelimiter;
    var translations = Drupal.t(singular + pluralDelimiter + plural, args, options).split(pluralDelimiter);
    var index = 0;
    if (typeof drupalTranslations !== 'undefined' && drupalTranslations.pluralFormula) {
      index = count in drupalTranslations.pluralFormula ? drupalTranslations.pluralFormula[count] : drupalTranslations.pluralFormula.default;
    } else if (args['@count'] !== 1) {
      index = 1;
    }
    return translations[index];
  };
  Drupal.encodePath = function (item) {
    return window.encodeURIComponent(item).replace(/%2F/g, '/');
  };
  Drupal.deprecationError = function (_ref) {
    var message = _ref.message;
    if (drupalSettings.suppressDeprecationErrors === false && typeof console !== 'undefined' && console.warn) {
      console.warn("[Deprecation] ".concat(message));
    }
  };
  Drupal.deprecatedProperty = function (_ref2) {
    var target = _ref2.target,
      deprecatedProperty = _ref2.deprecatedProperty,
      message = _ref2.message;
    if (!Proxy || !Reflect) {
      return target;
    }
    return new Proxy(target, {
      get: function get(target, key) {
        if (key === deprecatedProperty) {
          Drupal.deprecationError({
            message: message
          });
        }
        for (var _len = arguments.length, rest = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
          rest[_key - 2] = arguments[_key];
        }
        return Reflect.get.apply(Reflect, [target, key].concat(rest));
      }
    });
  };
  Drupal.theme = function (func) {
    if (func in Drupal.theme) {
      var _Drupal$theme;
      for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
      }
      return (_Drupal$theme = Drupal.theme)[func].apply(_Drupal$theme, args);
    }
  };
  Drupal.theme.placeholder = function (str) {
    return "<em class=\"placeholder\">".concat(Drupal.checkPlain(str), "</em>");
  };
})(Drupal, window.drupalSettings, window.drupalTranslations, window.console, window.Proxy, window.Reflect);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
if (window.jQuery) {
  jQuery.noConflict();
}
document.documentElement.className += ' js';
(function (Drupal, drupalSettings) {
  var domReady = function domReady(callback) {
    var listener = function listener() {
      callback();
      document.removeEventListener('DOMContentLoaded', listener);
    };
    if (document.readyState !== 'loading') {
      setTimeout(callback, 0);
    } else {
      document.addEventListener('DOMContentLoaded', listener);
    }
  };
  domReady(function () {
    Drupal.attachBehaviors(document, drupalSettings);
  });
})(Drupal, window.drupalSettings);;
/**
 * @file
 * Da Vinci Custom Code of the javascript behaviour.
 */

'use strict';

(function ($) {
  Drupal.behaviors.da_vinciTheme = {
    attach: function (context) {

      function querystring(key) {
        var re=new RegExp('(?:\\?|&)'+key+'=(.*?)(?=&|$)','gi');
        var r=[], m;
        while ((m=re.exec(document.location.search)) !== null) r.push(m[1]);
        return r;
      }
      function basename(str) {
        var base = new String(str).substring(str.lastIndexOf('/') + 1);
        if(base.lastIndexOf(".") != -1) {
          base = base.substring(0, base.lastIndexOf("."));
        }
        return base;
      }
      function updateQueryStringParameter(uri, key, value) {
        var re = new RegExp("([?|&])" + key + "=.*?(&|$)", "i");
        separator = uri.indexOf('?') !== -1 ? "&" : "?";
        var url = window.location.href;
        if (uri.match(re)) {
          url = uri.replace(re, '$1' + key + "=" + value + '$2');
        }
        else {
          url = uri + separator + key + "=" + value;
        }
        return url;
      }
      
    }
  };
})(jQuery);
;
/*!
 * jquery.unevent.js 0.2
 * https://github.com/yckart/jquery.unevent.js
 *
 * Copyright (c) 2013 Yannick Albert (http://yckart.com)
 * Licensed under the MIT license (http://www.opensource.org/licenses/mit-license.php).
 * 2013/07/26
**/
;(function ($) {
    var on = $.fn.on, timer;
    $.fn.on = function () {
        var args = Array.apply(null, arguments);
        var last = args[args.length - 1];

        if (isNaN(last) || (last === 1 && args.pop())) return on.apply(this, args);

        var delay = args.pop();
        var fn = args.pop();

        args.push(function () {
            var self = this, params = arguments;
            clearTimeout(timer);
            timer = setTimeout(function () {
                fn.apply(self, params);
            }, delay);
        });

        return on.apply(this, args);
    };
}(this.jQuery || this.Zepto));
;
/*
 * Viewport - jQuery selectors for finding elements in viewport
 *
 * Copyright (c) 2008-2009 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *  http://www.appelsiini.net/projects/viewport
 *
 */
(function($) {
    
    $.belowthefold = function(element, settings) {
        var fold = $(window).height() + $(window).scrollTop();
        return fold <= $(element).offset().top - settings.threshold;
    };

    $.abovethetop = function(element, settings) {
        var top = $(window).scrollTop();
        return top >= $(element).offset().top + $(element).height() - settings.threshold;
    };
    
    $.rightofscreen = function(element, settings) {
        var fold = $(window).width() + $(window).scrollLeft();
        return fold <= $(element).offset().left - settings.threshold;
    };
    
    $.leftofscreen = function(element, settings) {
        var left = $(window).scrollLeft();
        return left >= $(element).offset().left + $(element).width() - settings.threshold;
    };
    
    $.inviewport = function(element, settings) {
        return !$.rightofscreen(element, settings) && !$.leftofscreen(element, settings) && !$.belowthefold(element, settings) && !$.abovethetop(element, settings);
    };
    
    $.extend($.expr[':'], {
        "below-the-fold": function(a, i, m) {
            return $.belowthefold(a, {threshold : 0});
        },
        "above-the-top": function(a, i, m) {
            return $.abovethetop(a, {threshold : 0});
        },
        "left-of-screen": function(a, i, m) {
            return $.leftofscreen(a, {threshold : 0});
        },
        "right-of-screen": function(a, i, m) {
            return $.rightofscreen(a, {threshold : 0});
        },
        "in-viewport": function(a, i, m) {
            return $.inviewport(a, {threshold : 0});
        }
    });

    
})(jQuery);
;
/*
 CSS Browser Selector v0.4.0 (Nov 02, 2010)
 Rafael Lima (http://rafael.adm.br)
 http://rafael.adm.br/css_browser_selector
 License: http://creativecommons.org/licenses/by/2.5/
 Contributors: http://rafael.adm.br/css_browser_selector#contributors

 v0.5.0 2011-08-24
 andrew relkin

 modified, now detects:
 any version of Firefox
 more versions of Windows (Win8, Win7, Vista, XP, Win2k)
 more versions of IE under unique conditions
 more detailed support for Opera
 if "no-js" in HTML class: removes and replaces with "js" (<html class="no-js">)

 identifies
 browsers: Firefox; IE; Opera; Safari; Chrome, Konqueror, Iron
 browser versions: (most importantly: ie6, ie7, ie8, ie9)
 rendering engines: Webkit; Mozilla; Gecko
 platforms/OSes: Mac; Win: Win7, Vista, XP, Win2k; FreeBSD; Linux/x11
 devices: Ipod; Ipad; Iphone; WebTV; Blackberry; Android; J2me; mobile(generic)
 enabled technology: JS

 v0.6.3 2014-03-06
 @silasrm <silasrm@gmail.com>
 - Added support to IE11
 @see http://msdn.microsoft.com/en-us/library/ie/hh869301(v=vs.85).aspx
 @see http://msdn.microsoft.com/en-us/library/ie/bg182625(v=vs.85).aspx
 */

showLog=true;
function log(m) {if ( window.console && showLog ) {console.log(m); }  }

function css_browser_selector(u) {
    var	uaInfo = {},
        screens = [320, 480, 640, 768, 1024, 1152, 1280, 1440, 1680, 1920, 2560],
        allScreens = screens.length,
        ua=u.toLowerCase(),
        is=function(t) { return RegExp(t,"i").test(ua);  },
        version = function(p,n)
        {
            n=n.replace(".","_"); var i = n.indexOf('_'),  ver="";
            while (i>0) {ver += " "+ p+n.substring(0,i);i = n.indexOf('_', i+1);}
            ver += " "+p+n; return ver;
        },
        g='gecko',
        w='webkit',
        c='chrome',
        f='firefox',
        s='safari',
        o='opera',
        m='mobile',
        a='android',
        bb='blackberry',
        lang='lang_',
        dv='device_',
        html=document.documentElement,
        b=	[

            // browser
            ((!(/opera|webtv/i.test(ua))&&/msie\s(\d+)/.test(ua)||(/trident\/.*rv:([0-9]{1,}[\.0-9]{0,})/.test(ua))))?('ie ie'+(/trident\/4\.0/.test(ua) ? '8' : RegExp.$1 == '11.0'?'11':RegExp.$1))
                :is('firefox/')?g+ " " + f+(/firefox\/((\d+)(\.(\d+))(\.\d+)*)/.test(ua)?' '+f+RegExp.$2 + ' '+f+RegExp.$2+"_"+RegExp.$4:'')
                :is('gecko/')?g
                    :is('opera')?o+(/version\/((\d+)(\.(\d+))(\.\d+)*)/.test(ua)?' '+o+RegExp.$2 + ' '+o+RegExp.$2+"_"+RegExp.$4 : (/opera(\s|\/)(\d+)\.(\d+)/.test(ua)?' '+o+RegExp.$2+" "+o+RegExp.$2+"_"+RegExp.$3:''))
                        :is('konqueror')?'konqueror'

                            :is('blackberry') ?
                                ( bb +
                                    ( /Version\/(\d+)(\.(\d+)+)/i.test(ua)
                                            ? " " + bb+ RegExp.$1 + " "+bb+ RegExp.$1+RegExp.$2.replace('.','_')
                                            : (/Blackberry ?(([0-9]+)([a-z]?))[\/|;]/gi.test(ua)
                                                ? ' ' +bb+RegExp.$2 + (RegExp.$3?' ' +bb+RegExp.$2+RegExp.$3:'')
                                                : '')
                                    )
                                ) // blackberry

                                :is('android') ?
                                    (  a +
                                        ( /Version\/(\d+)(\.(\d+))+/i.test(ua)
                                            ? " " + a+ RegExp.$1 + " "+a+ RegExp.$1+RegExp.$2.replace('.','_')
                                            : '')
                                        + (/Android (.+); (.+) Build/i.test(ua)
                                            ? ' '+dv+( (RegExp.$2).replace(/ /g,"_") ).replace(/-/g,"_")
                                            :''	)
                                    ) //android

                                    :is('chrome')?w+   ' '+c+(/chrome\/((\d+)(\.(\d+))(\.\d+)*)/.test(ua)?' '+c+RegExp.$2 +((RegExp.$4>0) ? ' '+c+RegExp.$2+"_"+RegExp.$4:''):'')

                                        :is('iron')?w+' iron'

                                            :is('applewebkit/') ?
                                                ( w+ ' '+ s +
                                                    ( /version\/((\d+)(\.(\d+))(\.\d+)*)/.test(ua)
                                                            ?  ' '+ s +RegExp.$2 + " "+s+ RegExp.$2+RegExp.$3.replace('.','_')
                                                            :  ( / Safari\/(\d+)/i.test(ua)
                                                                ?
                                                                ( (RegExp.$1=="419" || RegExp.$1=="417" || RegExp.$1=="416" || RegExp.$1=="412" ) ? ' '+ s + '2_0'
                                                                    : RegExp.$1=="312" ? ' '+ s + '1_3'
                                                                        : RegExp.$1=="125" ? ' '+ s + '1_2'
                                                                            : RegExp.$1=="85" ? ' '+ s + '1_0'
                                                                                : '' )
                                                                :'')
                                                    )
                                                ) //applewebkit

                                                :is('mozilla/')?g
                                                    :''

            // mobile
            ,is("android|mobi|mobile|j2me|iphone|ipod|ipad|blackberry|playbook|kindle|silk")?m:''

            // os/platform
            ,is('j2me')?'j2me'
                :is('ipad|ipod|iphone')?
                    (
                        (
                            /CPU( iPhone)? OS (\d+[_|\.]\d+([_|\.]\d+)*)/i.test(ua)  ?
                                'ios' + version('ios',RegExp.$2) : ''
                        ) + ' ' + ( /(ip(ad|od|hone))/gi.test(ua) ?	RegExp.$1 : "" )
                    ) //'iphone'
                    //:is('ipod')?'ipod'
                    //:is('ipad')?'ipad'
                    :is('playbook')?'playbook'
                        :is('kindle|silk')?'kindle'
                            :is('playbook')?'playbook'
                                :is('mac')?'mac'+ (/mac os x ((\d+)[.|_](\d+))/.test(ua) ?    ( ' mac' + (RegExp.$2)  +  ' mac' + (RegExp.$1).replace('.',"_")  )     : '' )
                                    :is('win')?'win'+
                                        (is('windows nt 6.2')?' win8'
                                                :is('windows nt 6.1')?' win7'
                                                    :is('windows nt 6.0')?' vista'
                                                        :is('windows nt 5.2') || is('windows nt 5.1') ? ' win_xp'
                                                            :is('windows nt 5.0')?' win_2k'
                                                                :is('windows nt 4.0') || is('WinNT4.0') ?' win_nt'
                                                                    : ''
                                        )
                                        :is('freebsd')?'freebsd'
                                            :(is('x11|linux'))?'linux'
                                                :''

            // user agent language
            ,(/[; |\[](([a-z]{2})(\-[a-z]{2})?)[)|;|\]]/i.test(ua))?(lang+RegExp.$2).replace("-","_")+(RegExp.$3!=''?(' '+lang+RegExp.$1).replace("-","_"):''):''

            // beta: test if running iPad app
            ,( is('ipad|iphone|ipod') && !is('safari') )  ?  'ipad_app'  : ''


        ]; // b

    console.debug(ua);

    function screenSize() {
        var w = window.outerWidth || html.clientWidth;
        var h = window.outerHeight || html.clientHeight;
        uaInfo.orientation = ((w<h) ? "portrait" : "landscape");
        // remove previous min-width, max-width, client-width, client-height, and orientation
        html.className = html.className.replace(/ ?orientation_\w+/g, "").replace(/ [min|max|cl]+[w|h]_\d+/g, "")
        for (var i=(allScreens-1);i>=0;i--) { if (w >= screens[i] ) { uaInfo.maxw = screens[i]; break; }}
        widthClasses="";
        for (var info in uaInfo) { widthClasses+=" "+info+"_"+ uaInfo[info]  };
        html.className =  ( html.className +widthClasses  );
        return widthClasses;
    } // screenSize

    window.onresize = screenSize;
    screenSize();

    function retina(){
        var r = window.devicePixelRatio > 1;
        if (r) {
            html.className+=' retina';
        }
        else {
            html.className+=' non-retina';
        }
    }
    retina();

    var cssbs = (b.join(' ')) + " js ";
    html.className =   ( cssbs + html.className.replace(/\b(no[-|_]?)?js\b/g,"")  ).replace(/^ /, "").replace(/ +/g," ");

    return cssbs;
}

css_browser_selector(navigator.userAgent);
;
/**
 * @file
 * Your custom code into javascript behaviour.
 */

'use strict';

(function (Drupal, $) {
  $(document).ready(function () {

  });
})(Drupal, jQuery);

;
